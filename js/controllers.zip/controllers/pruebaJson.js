'use strict';

angular.module('starter.pruebajson', [])

.controller('PruebajsonController', function ($scope, $state, $stateParams, $timeout, 
											$ionicScrollDelegate, busyIndicator, $interval,
											$ionicBackdrop, $ionicModal, CategoriasService, 
											DataLocalService, $window , $ionicSlideBoxDelegate, 
											$mdBottomSheet, $mdToast, ContentProvider) {
	
	/*
	var band = true;

	$scope.openScan = function() {
		if (band) {
			band = false;
			cordova.exec(fileViewSuccess, fileViewFailure, "barcodeScanner", "scan");			
		} else{
			console.log('intento abrir la camara de nuevo');
		}
	}

	function fileViewSuccess(result) {
		alert("We got a barcode\n" +
                "Result: " + result.text + "\n" +
                "Format: " + result.format + "\n" +
                "Cancelled: " + result.cancelled);
		band = true;
	}

	function fileViewFailure(error) {
    	alert("Scanning failed: " + error);
    	band = true;
    }
    */
    $scope.getDataConsultaFacturacion = function (){
    	//var parametro1 	= 'categorias';
        var invocationData = getEstadoFacturacion();

        WL.Client.invokeProcedure(invocationData,{
            onSuccess : function(result) {                
                var httpStatusCode = result.status;
                if (200 == httpStatusCode) {
                    var invocationResult = result.invocationResult;
                    var isSuccessful = invocationResult.isSuccessful;
                    if (true == isSuccessful) {                            
                        console.log('datos ya validados::' + JSON.stringify(invocationResult.estado));
                    } 
                    else {                        
                        console.log('No es successful');
                        //WL.SimpleDialog.show(msgTitulo, msg, [ { text: "Aceptar", handler: function(){} } ]);
                    }                    
                } 
                else {
                    console.log('Error de servidor != 200');
                    //WL.SimpleDialog.show(msgTitulo, msg, [ { text: "Aceptar", handler: function(){} } ]);
                }
            },
            onFailure : function() {
                console.log('sin respuesta del servidor');
                //WL.SimpleDialog.show(msgTitulo, msg, [ { text: "Aceptar", handler: function(){} } ]);
            }
        });
    }

    $scope.rfcInvalido = 0;
    $scope.test = {};

    $scope.validaDatos = function(){
        var name = $scope.test.name;
        var re = /^[a-zA-Z0-9]/;

        if (re.test(name)){
            console.log("caracteres validos");
            $scope.rfcInvalido = 0;
        }else{
            console.log("caracteres invalidos");
            $scope.rfcInvalido = 1;
        }
    }
    
});